# 1. Создать программно файл в текстовом формате, записать в него построчно данные,
# вводимые пользователем. Об окончании ввода данных свидетельствует пустая строка.
#
# with open("test_1_2.txt", "w", encoding="utf=8") as my_file:
#     content = input("Введите что-то,чтобы закончить, нажмите q ")
#     print(content, file=my_file)
#     while True:
#         content = input("Введите еще что-то. чтобы закончить, нажмите q ")
#         print(content, file=my_file)
#         if content == '' or content == " " or content == "q":
#             break

# 2  Создать текстовый файл (не программно), сохранить в нем несколько строк,
#  выполнить подсчет количества строк, количества слов в каждой строке

# my_file = open('test_1_2.txt', "r", encoding="utf=8")
# content = my_file.readlines()
# print(f"Количество строк в файле  {len(content)}")
# list_lines = [len(el.split()) for el in content]
# for i, numbers in enumerate(list_lines):
#     print(f"В {i+1} строке {numbers} слов")
# my_file.close()

# # 3 Здесь небольшое предисловие, было интересно реализовать самому введение данных
#
# # try:
# #     with open("test_3", "w", encoding="utf=8") as my_file:
# #         workers_number = int(input("Сколько у вас сотрудников? "))
# #         i = 1
# #         while i <= workers_number:
# #             worker = input(f"Введите фамилию {i} сотрудника: ")
# #             salary = input(f"Введите зарплату {i} сотрудника цифрой: ")
# #             print(worker, salary, file=my_file)
# #             i += 1
# # except IOError as err:
# #     print(err)
#
#
# # 3 Здесь решение по готовому файлу
#
# with open('test_3', 'r', encoding='utf-8') as my_file:
#     workers = {}
#     for line in my_file:
#         key, value = line.split()
#         workers[key] = value
#         if int(value) < 20000:
#             print(f'У сотрудника по фамилии {key}: зарплата меньше 20000')
#         else:
#             print(f"У сотрудника по фамилии {key}: зарплата больше 20000")
#     salary = []
#     for x in workers:
#         s = int(workers[x])
#         salary.append(s)
#     print(f"Всего вы платите {sum(salary)}, средняя зарплата {sum(salary) / len(workers)}")


# 4
#
# with open("test_4", "r", encoding="utf=8") as my_file:
#     content = my_file.read()
#     list = content.split()
#
# dict = {"One":" Один", "Two":"Два", "Three": "Три", "Four":"Четыре"}
# for item in list:
#     if item in dict:
#         list[list.index(item)] = dict[item]
#
# full_data = ' '.join(list)
# print(full_data)

#

# 5. Создать (программно) текстовый файл, записать в него программно набор чисел, разделенных пробелами.
# Программа должна подсчитывать сумму чисел в файле и выводить ее на экран.

# try:
#     with open("test_5.txt", "w", encoding="utf=8") as my_file:
#         numbers_amount = int(input("Сколько чисел вы хотите сложить? "))
#         i = 1
#         while i <= numbers_amount:
#             number = input(f"Введите число {i}: ")
#             print(number , file=my_file)
#             i += 1
# except IOError as err:
#     print(err)
#
# try:
#     with open("test_5.txt", "r", encoding="utf8") as my_file:
#         numbers = my_file.read()
#         print(sum([int(item) for item in numbers.split()]))
#
# except ValueError as err:
#     print(err)

#6 РЕШИЛ НЕ САМ!!! подсказали однокурсники! но я вроде бы въехал что в коде написано)))
# Необходимо создать (не программно) текстовый файл,
# где каждая строка описывает учебный предмет и наличие лекционных, практических и лабораторных занятий
# по этому предмету и их количество.
# Важно, чтобы для каждого предмета не обязательно были все типы занятий. Сформировать словарь,
# содержащий название предмета и общее количество занятий по нему. Вывести словарь на экран.

# with open("classes.txt", "r", encoding= "utf-8") as my_file:

# result = {}
# for line in open('classes.txt'):
#     items = line.split(':', 1)
#     numbers = ''.join(filter(lambda s: (s.isdigit() or s == ' '), items[1]))
#     result[items[0]] = sum([int(i) for i in numbers.split()])
#
# print(result)

# 7 7. Создать (не программно) текстовый файл, в котором каждая строка должна содержать данные о фирме:
# название, форма собственности, выручка, издержки.
# Пример строки файла: firm_1 ООО 10000 5000.
#
# try:
#     with open("test7.txt", "w", encoding="utf=8") as my_file:
#         firm_number = int(input("Сколько фирм? "))
#         i = 1
#         while i <= firm_number:
#             firm = input(f"Введите название {i} фирмы на английском: ")
#             income = input(f"Введите выручку {i} фирмы цифрой: ")
#             outcome = input(f"Введите издержки {i} фирмы цифрой: ")
#             print(firm, income, outcome, file=my_file)
#             i += 1
# except IOError as err:
#     print(err)

# НЕ РЕШЕНА
# Необходимо построчно прочитать файл, вычислить прибыль каждой компании, а также среднюю прибыль.
# Если фирма получила убытки, в расчет средней прибыли ее не включать.
# Далее реализовать список. Он должен содержать словарь с фирмами и их прибылями,
# а также словарь со средней прибылью. Если фирма получила убытки,
# также добавить ее в словарь (со значением убытков).
# Пример списка: [{“firm_1”: 5000, “firm_2”: 3000, “firm_3”: 1000}, {“average_profit”: 2000}].

# def filter_num(str_):
#     number = ''.join([i for i in str_ if i.isdigit()])
#     if number:
#         return int(number)
#     return 0

# def sum_el(data):
#     return sum([filter_num(str_) for str_ in data.split()])

# with open('test7.txt', 'r', encoding='utf-8') as my_file:
#     for line in my_file:
#         for str_ in line.split():
#
#         # firms = line.split(" ")
#         # for el in firms:



        # print(firms)
        # print(type(firms))
        # firms[key] = value
        # if int(value) > 0:
        #     print(f'Фирма {key} прибыльна')
        # elif int(value) == 0:
        #     print(f"Фирма {key} работает в ноль")
        # else:
        #     print(f"Фирма {key} убыточна")

    # salary = []
    # for x in workers:
    #     s = int(workers[x])
    #     salary.append(s)
    # print(f"Всего вы платите {sum(salary)}, средняя зарплата {sum(salary) / len(workers)}")



# Итоговый список сохранить в виде json-объекта в соответствующий файл.
# Пример json-объекта:
# [{"firm_1": 5000, "firm_2": 3000, "firm_3": 1000}, {"average_profit": 2000}]
# Подсказка: использовать менеджеры контекста.
